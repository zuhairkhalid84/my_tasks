﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R04_Product : RecordBase
    {
        public R04_Product(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Product))
            {
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapProductFields);      
                new R05_LHC(reader, row, reader.ReadLine());
            }
            else
            {
                new R05_LHC(reader, row, currentLine);
            }

        }
    }
}

