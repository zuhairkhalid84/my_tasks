﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Data.Common;
using System.Collections.Generic;

using ABnote.ProFound;
using ABnote.ProFound.Interfaces.Abstract;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public class FileParser : ParserComponent
    {
        #region Fields
        
        #endregion

        #region Public Methods And Operators

        /// <summary>
        /// Configures the component according to the configuration received.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public override void Configure(string configuration)
        {
            GlobalObjects.configuration = new ConfigProfileHelper(configuration);
            GlobalObjects.orderData = new DataTable(TableNameConstants.OrderData);
            foreach (var field in GlobalObjects.configuration.MapAllFields)
            {
                GlobalObjects.orderData.Columns.Add(new DataColumn(field.Name
                                                    , typeof(string)));
            }
            foreach (var field in GlobalObjects.configuration.MapPersonFields)
            {
                for (int i = 1; i <= 20; i++)
                GlobalObjects.orderData.Columns.Add(new DataColumn(field.Name + "_" + i
                                                    , typeof(string)));
            }
            foreach (var field in GlobalObjects.configuration.MapCorporateFields)
            {
                for (int i = 1; i <= 20; i++)
                    GlobalObjects.orderData.Columns.Add(new DataColumn(field.Name + "_" + i
                                                        , typeof(string)));
            }
        }

        /// <summary>
        /// Prepares component for processing data.
        /// </summary>
        public override void Prepare()
        {
            
        }

        /// <summary>
        /// Parses the specified order data.
        /// </summary>
        /// <param name="orderData">The order data.</param>
        /// <returns></returns>
        public override DataSet Process(IOrderData orderData)
        {
            var dataSet = new DataSet();
            var reader = new StreamReader(orderData.GetStream());
            //DataRow nextRow;
            string currentLine;
            string firstLine;
            try
            {
                using (reader)
                {
                    firstLine = reader.ReadLine();
                    if (firstLine == null)
                    {
                        dataSet.Tables.Add(GlobalObjects.orderData);
                        return dataSet;
                    }
                    if (!firstLine.StartsWith("H->"))// Strip off header
                        throw new Exception("Welcome File format is not correct");

                        GlobalObjects.nextLine = reader.ReadLine();
                    do
                    {
                        DataRow newPackRow = GlobalObjects.orderData.NewRow();
                        new R01_Address(reader, newPackRow, GlobalObjects.nextLine);
                        GlobalObjects.orderData.Rows.Add(newPackRow);
                    }
                    while (GlobalObjects.nextLine.Contains(RecordTypes.Address));
                    //{
                    //    nextRow = GlobalObjects.orderData.NewRow();
                    //    new R01_Address(reader, newPackRow, GlobalObjects.nextLine);
                    //}

                }
            }
            catch
            {
                throw;
            }

            dataSet.Tables.Add(GlobalObjects.orderData);
            return dataSet;
        }

        #endregion
    }
}