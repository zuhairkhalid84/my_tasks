﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public class R00_PackStart : RecordBase
    {
        public R00_PackStart(StreamReader reader, DataRow row, string currentLine)
        {
            PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapIndexFields);
            new R01_Address(reader, row, reader.ReadLine());            
        }
    }
}
