﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Timers;
using System.Windows.Threading;
using ABnote.ProFound.PMS.ServiceSeam;

namespace ABnote.ProFound.PMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DAL _database;

        string[] steps = new string[] {"Datacard","cardink"};

        private Dispatcher _dispatcher = Dispatcher.CurrentDispatcher;

        public delegate void UpdateProgressBarDelegate(System.Windows.DependencyProperty dp, Object value);

        public MainWindow()
        {
            SLRegistrationService registrationService = new SLRegistrationService();
            InitializeComponent();
            //_database = new DAL("Server=172.31.33.130;Database=ProFound;User Id=user_WfWorker;Password=4fsdFwo#32S;MultipleActiveResultSets=True;");
            //ShowJobList();
            
        }

        private void ShowJobList()
        {
            //ConfigGrid.ItemsSource = _database.JobList(steps).Tables[0].DefaultView;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnJobAssign_Click(object sender, RoutedEventArgs e)
        {
            NavigateTo(new Uri("JobAssign.xaml", UriKind.RelativeOrAbsolute));
        }

        public void NavigateTo(Uri uri)
        {
            //uxInputFrame.Source = uri;
            uxInputFrame.NavigationService.Navigate(uri);
        }

        private void btnJobViewNew_Click(object sender, RoutedEventArgs e)
        {
            NavigateTo(new Uri("JobViewNew.xaml", UriKind.RelativeOrAbsolute));
        }
        private void uxInputFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
          //  UpdateProgressBarDelegate updatePbDelegate = new UpdateProgressBarDelegate(ProgressBar.SetValue);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSplitSubProduction_Click(object sender, RoutedEventArgs e)
        {
            NavigateTo(new Uri("SubProductionSplit.xaml", UriKind.RelativeOrAbsolute));
        }
        
        
        
        //private void UpdateProgressBarDelegate
        //{
        //    //ProgressBar.Dispatcher.invoke(DispatcherPriority.Normal,
        //                            //new NextPrimeDelegate(CheckNextNumber). )
            
        //    UpdateProgressBarDelegate updatePbDelegate = new UpdateProgressBarDelegate(ProgressBar.SetValue);
        //    Dispatcher.Invoke(updatePbDelegate, 
        //            System.Windows.Threading.DispatcherPriority.Background, 
        //            new object[] { ProgressBar.ValueProperty, value });
        //}
    }

    public class Ticker : INotifyPropertyChanged
    {
        public Ticker()
        {
            Timer timer = new Timer();
            timer.Interval = 1000; // 1 second updates
            timer.Elapsed += timer_Elapsed;
            timer.Start();
        }

        public DateTime Now
        {
            get { return DateTime.Now; }
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Now"));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
