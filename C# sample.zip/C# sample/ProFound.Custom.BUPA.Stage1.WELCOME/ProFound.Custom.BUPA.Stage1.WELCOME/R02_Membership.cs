﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R02_Membership : RecordBase
    {
        public R02_Membership(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Membership))
            {
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapMembershipFields);
                new R03_Person(reader, row, reader.ReadLine());
            }
            else
            {
                new R03_Person(reader, row, currentLine);
            }

        }
    }
}

