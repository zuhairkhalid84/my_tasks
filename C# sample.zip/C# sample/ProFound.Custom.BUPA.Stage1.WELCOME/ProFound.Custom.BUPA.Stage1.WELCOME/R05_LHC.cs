﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R05_LHC : RecordBase
    {
        public R05_LHC(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Premium))
            {
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapLHCFields);
                new R06_Payment(reader, row, reader.ReadLine());
            }
            else
            {
                new R06_Payment(reader, row, currentLine);
            }

        }
    }
}

