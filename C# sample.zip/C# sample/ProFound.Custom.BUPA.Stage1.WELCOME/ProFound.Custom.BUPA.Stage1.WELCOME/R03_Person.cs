﻿using System;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R03_Person : RecordBase
    {
        public R03_Person(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Person))
            {                
                PopulateFields(currentLine, row, "_1", GlobalObjects.configuration.MapPersonFields);             
                string nextLine;
                int index = 2;
                while (Regex.IsMatch(nextLine = reader.ReadLine(), @"03-\d{2}-PERCOVER"))
                //while ((nextLine = reader.ReadLine()).Contains(g => Regex.IsMatch(nextLine, "ss")))
                {                                        
                    PopulateFields(nextLine, row, "_" + index, GlobalObjects.configuration.MapPersonFields);
                    index++;
                }
                new R04_Product(reader, row, nextLine); 
            }
            else
            {
                new R04_Product(reader, row, currentLine);
            }

        }
    }
}