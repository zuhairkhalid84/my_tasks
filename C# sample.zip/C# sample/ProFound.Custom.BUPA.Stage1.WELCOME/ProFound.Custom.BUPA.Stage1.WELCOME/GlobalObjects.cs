﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{    public static class GlobalObjects
    {
        public static DataTable orderData;
        public static ConfigProfileHelper configuration;
        public static string nextLine;
    }
}
