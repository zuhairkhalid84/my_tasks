﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R06_Payment : RecordBase
    {
        public R06_Payment(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Payment))
            {
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapPaymentFields);   
                            
                new R07_Corporate(reader, row, reader.ReadLine());
            }
            else
            {
                new R07_Corporate(reader, row, currentLine);
            }

        }
    }
}

