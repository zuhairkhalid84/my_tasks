﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public class R01_Address : RecordBase
    {
        public R01_Address(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Address))
            {
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapIndexFields);
                PopulateFields(currentLine, row, string.Empty, GlobalObjects.configuration.MapAddressFields);
                new R02_Membership(reader, row, reader.ReadLine());
            }
            else
            {
                new R02_Membership(reader, row, currentLine);
            }

        }
    }
}
