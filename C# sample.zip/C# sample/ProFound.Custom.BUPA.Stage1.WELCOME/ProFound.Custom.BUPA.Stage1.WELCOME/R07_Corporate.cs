﻿using System;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R07_Corporate : RecordBase
    {
        public R07_Corporate(StreamReader reader, DataRow row, string currentLine)
        {
            if (currentLine.Contains(RecordTypes.Corporate))
            {
                PopulateFields(currentLine, row, "_1", GlobalObjects.configuration.MapCorporateFields);           
                string nextLine;
                int index = 2;
                while (Regex.IsMatch(nextLine = reader.ReadLine(), @"07-\d{2}-CORPORATE"))
                {                    
                    PopulateFields(nextLine, row, "_" + index, GlobalObjects.configuration.MapCorporateFields);                    
                    index++;
                }
                GlobalObjects.nextLine = nextLine;
            }
            else
            {
                //new R01_Address(reader, row, currentLine);
                GlobalObjects.nextLine = currentLine;
            }

        }
    }
}