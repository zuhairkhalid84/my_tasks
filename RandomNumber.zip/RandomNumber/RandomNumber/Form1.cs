﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomNumber
{
    public partial class frmRandomNumber : Form
    {
        #region Fields
        HashSet<int> numbers;
        #endregion

        #region Constructor
        public frmRandomNumber()
        {
            InitializeComponent();
            this.txtStartRange.KeyPress += new KeyPressEventHandler(txtStartRange_KeyPress);
            this.txtEndRange.KeyPress += new KeyPressEventHandler(txtStartRange_KeyPress);
        }
        #endregion
        
        #region Events
        private void btnGenerateRandom_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            LoadNumbers(); // Load numbers in the array
           
            if (ValidationCheck())
            {
                lblRandomNumber.Text = Random(Convert.ToInt32(txtStartRange.Text), Convert.ToInt32(txtEndRange.Text)).ToString();
            }

        }
        private void txtStartRange_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !Char.IsNumber(e.KeyChar) && e.KeyChar != 8;
        }
        #endregion

        #region Methods

        private bool ValidationCheck()
        {
            string startRange = txtStartRange.Text;
            string endRange = txtEndRange.Text;
            if (txtStartRange.Text == "" || txtEndRange.Text == "")
            {
                lblError.Text = "Start Range or End Range cannot be null";
                return false;
            }
            else if (Convert.ToInt32(startRange) > 51 || Convert.ToInt32(startRange) < 1)
            {
                lblError.Text = "Start Range should be between 1 and 51";
                return false;
            }
            else if (Convert.ToInt32(endRange) > 52 || Convert.ToInt32(endRange) < 2)
            {
                lblError.Text = "End Range should be between 2 and 52";
                return false;
            }
            else if (!numbers.Any())
            {
                lblError.Text = "Range is not populated";
                return false;
            }
            return true;
        }
        private void LoadNumbers()
        {
            // Since Hashset handles the duplication
            numbers = new HashSet<int>();
            var random = new Random();
            do numbers.Add(random.Next(1, 53));                
            while (numbers.Count <= 51);
        }
        private int Random(int startRange, int endRange)
        {           
           return numbers.First(t => t >= startRange && t <= endRange);
        }
        #endregion
    }
}
