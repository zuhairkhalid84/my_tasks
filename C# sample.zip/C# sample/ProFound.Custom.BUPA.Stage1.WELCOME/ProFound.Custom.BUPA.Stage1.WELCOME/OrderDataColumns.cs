﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public static class OrderDataColumns
    {
        public const string WEL_LNDSTO = "WEL_LNDSTO";
        public const string WEL_LNAADD = "WEL_LNAADD";
        public const string WEL_LSPSIO = "WEL_LSPSIO";
        public const string WEL_SERV_CTRE = "WEL_SERV_CTRE";
        public const string WEL_LBRANO = "WEL_LBRANO";
        public const string WEL_LCOVNO = "WEL_LCOVNO";
        public const string WEL_LTHEME = "WEL_LTHEME";
        public const string WEL_REC_TYPE = "WEL_REC_TYPE";
        public const string WEL_POSTCODE = "WEL_POSTCODE";
        public const string WEL_RUN_DATE = "WEL_RUN_DATE";
        public const string WEL_SEQ_NO = "WEL_SEQ_NO";
        public const string WEL_REC_SEQ_NO = "WEL_REC_SEQ_NO";
        public const string WEL_PRVIND = "WEL_PRVIND";
        public const string WEL_LGSRTO = "WEL_LGSRTO";
        public const string WEL_DSEGNO = "WEL_DSEGNO";
        public const string WEL_ALADTLE = "WEL_ALADTLE";
        public const string WEL_ALADGVN = "WEL_ALADGVN";
        public const string WEL_ALADINI = "WEL_ALADINI";
        public const string WEL_ALADSNM = "WEL_ALADSNM";
        public const string WEL_ALMEMN3 = "WEL_ALMEMN3";
        public const string WEL_ALSALU2 = "WEL_ALSALU2";
        public const string WEL_ALADDMN_1 = "WEL_ALADDMN_1";
        public const string WEL_ALADDMN_2 = "WEL_ALADDMN_2";
        public const string WEL_ALADDMN_3 = "WEL_ALADDMN_3";
        public const string WEL_ALADDMN_4 = "WEL_ALADDMN_4";
        public const string WEL_LENRTY = "WEL_LENRTY";
        public const string WEL_LPCGDT = "WEL_LPCGDT";
        public const string WEL_LENRDT = "WEL_LENRDT";
        public const string WEL_LEXTDT = "WEL_LEXTDT";
        public const string WEL_LREAS2 = "WEL_LREAS2";
        public const string WEL_LFUNN2 = "WEL_LFUNN2";
        public const string WEL_LBADN2 = "WEL_LBADN2";
        public const string WEL_LLAPRD = "WEL_LLAPRD";
        public const string WEL_LBUSTY = "WEL_LBUSTY";
        public const string WEL_LBUSI4 = "WEL_LBUSI4";
        public const string WEL_LTMRED = "WEL_LTMRED";
        public const string WEL_LCSRVC = "WEL_LCSRVC";
        public const string WEL_LAMXID = "WEL_LAMXID";
        public const string WEL_LJOIDT = "WEL_LJOIDT";
        public const string WEL_LMEMTY = "WEL_LMEMTY";
        public const string WEL_LFMYTY = "WEL_LFMYTY";
        public const string WEL_LFMYDS = "WEL_LFMYDS";
        public const string WEL_LPHSTY = "WEL_LPHSTY";
        public const string WEL_LPHSCV = "WEL_LPHSCV";
        public const string WEL_LDENOS = "WEL_LDENOS";
        public const string WEL_LPARAID = "WEL_LPARAID";
        public const string WEL_LPSRTY = "WEL_LPSRTY";
        public const string WEL_LPSRID = "WEL_LPSRID";
        public const string WEL_LEPEID = "WEL_LEPEID";
        public const string WEL_LFLSID = "WEL_LFLSID";
        public const string WEL_LLHCT1 = "WEL_LLHCT1";
        public const string WEL_LBRANA = "WEL_LBRANA";
        public const string WEL_LBRAND = "WEL_LBRAND";
        public const string WEL_LBADGA = "WEL_LBADGA";
        public const string WEL_LBADGD = "WEL_LBADGD";
        public const string WEL_LORGXT = "WEL_LORGXT";
        public const string WEL_LEMAIL = "WEL_LEMAIL";
        public const string WEL_OSHCAOF = "WEL_OSHCAOF";
        public const string WEL_ORGXID = "WEL_ORGXID";
        public const string WEL_ORGXGN = "WEL_ORGXGN";
        public const string WEL_ORGXGA1 = "WEL_ORGXGA1";
        public const string WEL_ORGXGA2 = "WEL_ORGXGA2";
        public const string WEL_ORGXGA3 = "WEL_ORGXGA3";
        public const string WEL_ORGXGA4 = "WEL_ORGXGA4";
        public const string WEL_STUDNUM = "WEL_STUDNUM";
        public const string WEL_VISA_NUMBER = "WEL_VISA_NUMBER";
        public const string WEL_DATEPT = "WEL_DATEPT";
        public const string WEL_LDEGVN = "WEL_LDEGVN";
        public const string WEL_LDEINI = "WEL_LDEINI";
        public const string WEL_LDESNM = "WEL_LDESNM";
        public const string WEL_LDERLN = "WEL_LDERLN";
        public const string WEL_LDESFX = "WEL_LDESFX";
        public const string WEL_LDEDOB = "WEL_LDEDOB";
        public const string WEL_LDESTY = "WEL_LDESTY";
        public const string WEL_LPKGNS = "WEL_LPKGNS";
        public const string WEL_LPKGNR = "WEL_LPKGNR";
        public const string WEL_LDESOP = "WEL_LDESOP";
        public const string WEL_LPHYSI = "WEL_LPHYSI";
        public const string WEL_LWORLD = "WEL_LWORLD";
        public const string WEL_LPERAC = "WEL_LPERAC";
        public const string WEL_LTRAVE = "WEL_LTRAVE";
        public const string WEL_LQUEND = "WEL_LQUEND";
        public const string WEL_LEXBNP = "WEL_LEXBNP";
        public const string WEL_LEXBNC = "WEL_LEXBNC";
        public const string WEL_LPKCDE = "WEL_LPKCDE";
        public const string WEL_LPKGFL = "WEL_LPKGFL";
        public const string WEL_HMKT_SEG = "WEL_HMKT_SEG";
        public const string WEL_LHSPOI = "WEL_LHSPOI";
        public const string WEL_LHSPDS = "WEL_LHSPDS";
        public const string WEL_LHSPEO = "WEL_LHSPEO";
        public const string WEL_LHSPEB = "WEL_LHSPEB";
        public const string WEL_LHSPXO = "WEL_LHSPXO";
        public const string WEL_LHSPVB = "WEL_LHSPVB";
        public const string WEL_LHSPLO = "WEL_LHSPLO";
        public const string WEL_AMKT_SEG = "WEL_AMKT_SEG";
        public const string WEL_LANCOI = "WEL_LANCOI";
        public const string WEL_LANCDS = "WEL_LANCDS";
        public const string WEL_LANCEO = "WEL_LANCEO";
        public const string WEL_LANCEB = "WEL_LANCEB";
        public const string WEL_LANCXO = "WEL_LANCXO";
        public const string WEL_LANCVB = "WEL_LANCVB";
        public const string WEL_LANCLO = "WEL_LANCLO";
        public const string WEL_LMEDCC = "WEL_LMEDCC";
        public const string WEL_LMEDOI = "WEL_LMEDOI";
        public const string WEL_LMEDDS = "WEL_LMEDDS";
        public const string WEL_LMEDEO = "WEL_LMEDEO";
        public const string WEL_LMEDEB = "WEL_LMEDEB";
        public const string WEL_LMEDXO = "WEL_LMEDXO";
        public const string WEL_LMEDVB = "WEL_LMEDVB";
        public const string WEL_LMEDLO = "WEL_LMEDLO";
        public const string WEL_LNPHCC = "WEL_LNPHCC";
        public const string WEL_LNPHOI = "WEL_LNPHOI";
        public const string WEL_LNPHDS = "WEL_LNPHDS";
        public const string WEL_LNPHEO = "WEL_LNPHEO";
        public const string WEL_LNPHEB = "WEL_LNPHEB";
        public const string WEL_LNPHXO = "WEL_LNPHXO";
        public const string WEL_LNPHVB = "WEL_LNPHVB";
        public const string WEL_LNPHLO = "WEL_LNPHLO";
        public const string WEL_LSRSEC = "WEL_LSRSEC";
        public const string WEL_LSRSED = "WEL_LSRSED";
        public const string WEL_LEXNPD = "WEL_LEXNPD";
        public const string WEL_LPHIRF = "WEL_LPHIRF";
        public const string WEL_LLHCFL = "WEL_LLHCFL";
        public const string WEL_LBASER = "WEL_LBASER";
        public const string WEL_LBAS30 = "WEL_LBAS30";
        public const string WEL_LBASAL = "WEL_LBASAL";
        public const string WEL_LBAS3A = "WEL_LBAS3A";
        public const string WEL_LREBAM = "WEL_LREBAM";
        public const string WEL_LALLFL = "WEL_LALLFL";
        public const string WEL_LALPER = "WEL_LALPER";
        public const string WEL_LALLAM = "WEL_LALLAM";
        public const string WEL_LLHCNA = "WEL_LLHCNA";
        public const string WEL_LLHCWA = "WEL_LLHCWA";
        public const string WEL_LL30NA = "WEL_LL30NA";
        public const string WEL_LL30WA = "WEL_LL30WA";
        public const string WEL_LLOADP = "WEL_LLOADP";
        public const string WEL_LLOADA = "WEL_LLOADA";
        public const string WEL_LLOAD1 = "WEL_LLOAD1";
        public const string WEL_LLOAD2 = "WEL_LLOAD2";
        public const string WEL_CEAGE1 = "WEL_CEAGE1";
        public const string WEL_CEAGE2 = "WEL_CEAGE2";
        public const string WEL_NODYS1 = "WEL_NODYS1";
        public const string WEL_NODYS2 = "WEL_NODYS2";
        public const string WEL_LNRATE = "WEL_LNRATE";
        public const string WEL_REBATE_PERCENTAGE = "WEL_REBATE_PERCENTAGE";
        public const string WEL_REBATE_REASON_CODE = "WEL_REBATE_REASON_CODE";
        public const string WEL_REBATE_TIER_CODE = "WEL_REBATE_TIER_CODE";
        public const string WEL_LPDSNO = "WEL_LPDSNO";
        public const string WEL_LPDSTY = "WEL_LPDSTY";
        public const string WEL_LPDSNM = "WEL_LPDSNM";
        public const string WEL_LPYRCD = "WEL_LPYRCD";
        public const string WEL_LALLGP = "WEL_LALLGP";
        public const string WEL_LALLTY = "WEL_LALLTY";
        public const string WEL_LALLPC = "WEL_LALLPC";
        public const string WEL_LRGATY = "WEL_LRGATY";
        public const string WEL_LRGPAC = "WEL_LRGPAC";
        public const string WEL_LRGBSB = "WEL_LRGBSB";
        public const string WEL_LRGINO = "WEL_LRGINO";
        public const string WEL_LRGINM = "WEL_LRGINM";
        public const string WEL_LRGBNM = "WEL_LRGBNM";
        public const string WEL_LRGBRN = "WEL_LRGBRN";
        public const string WEL_LRGPDT = "WEL_LRGPDT";
        public const string WEL_LRGPYF = "WEL_LRGPYF";
        public const string WEL_LRGPYA = "WEL_LRGPYA";
        public const string WEL_LSGATY = "WEL_LSGATY";
        public const string WEL_LSGPAC = "WEL_LSGPAC";
        public const string WEL_LSGBSB = "WEL_LSGBSB";
        public const string WEL_LSGINO = "WEL_LSGINO";
        public const string WEL_LSGINM = "WEL_LSGINM";
        public const string WEL_LSGBNM = "WEL_LSGBNM";
        public const string WEL_LSGBRN = "WEL_LSGBRN";
        public const string WEL_LSGPDT = "WEL_LSGPDT";
        public const string WEL_LSGPYF = "WEL_LSGPYF";
        public const string WEL_LSGPYA = "WEL_LSGPYA";
        public const string WEL_LSTPYF = "WEL_LSTPYF";
        public const string WEL_LSTPYA = "WEL_LSTPYA";
        public const string WEL_CORP_TABLE = "WEL_CORP_TABLE";
        public const string WEL_CORP_CODE = "WEL_CORP_CODE";
        public const string WEL_CORP_LINE = "WEL_CORP_LINE ";


    }

    public static class RecordTypes
    {
        public const string PackStart = "R00";
        public const string Address = "01-01-ADDRESS";
        public const string Membership = "02-01-MEMBERSHP";
        public const string Person = "03-01-PERCOVER";
        public const string Product = "04-01-PRODUCT";
        public const string Premium = "05-01-LHC";
        public const string Payment = "06-01-PAYMENT";
        public const string Corporate = "07-01-CORPORATE";
        public const string PackEnd = "R10";
    }

        public enum ColumnNames
    {
        WEL_LNDSTO,
        WEL_LNAADD,
        WEL_LSPSIO,
        WEL_SERV_CTRE,
        WEL_LBRANO,
        WEL_LCOVNO,
        WEL_LTHEME,
        WEL_REC_TYPE,
        WEL_POSTCODE,
        WEL_RUN_DATE,
        WEL_SEQ_NO,
        WEL_REC_SEQ_NO,
        WEL_PRVIND,
        WEL_LGSRTO,
        WEL_DSEGNO,
        WEL_ALADTLE,
        WEL_ALADGVN,
        WEL_ALADINI,
        WEL_ALADSNM,
        WEL_ALMEMN3,
        WEL_ALSALU2,
        WEL_ALADDMN_1,
        WEL_ALADDMN_2,
        WEL_ALADDMN_3,
        WEL_ALADDMN_4,
        WEL_LENRTY,
        WEL_LPCGDT,
        WEL_LENRDT,
        WEL_LEXTDT,
        WEL_LREAS2,
        WEL_LFUNN2,
        WEL_LBADN2,
        WEL_LLAPRD,
        WEL_LBUSTY,
        WEL_LBUSI4,
        WEL_LTMRED,
        WEL_LCSRVC,
        WEL_LAMXID,
        WEL_LJOIDT,
        WEL_LMEMTY,
        WEL_LFMYTY,
        WEL_LFMYDS,
        WEL_LPHSTY,
        WEL_LPHSCV,
        WEL_LDENOS,
        WEL_LPARAID,
        WEL_LPSRTY,
        WEL_LPSRID,
        WEL_LEPEID,
        WEL_LFLSID,
        WEL_LLHCT1,
        WEL_LBRANA,
        WEL_LBRAND,
        WEL_LBADGA,
        WEL_LBADGD,
        WEL_LORGXT,
        WEL_LEMAIL,
        WEL_OSHCAOF,
        WEL_ORGXID,
        WEL_ORGXGN,
        WEL_ORGXGA1,
        WEL_ORGXGA2,
        WEL_ORGXGA3,
        WEL_ORGXGA4,
        WEL_STUDNUM,
        WEL_VISA_NUMBER,
        WEL_DATEPT,
        WEL_LDEGVN,
        WEL_LDEINI,
        WEL_LDESNM,
        WEL_LDERLN,
        WEL_LDESFX,
        WEL_LDEDOB,
        WEL_LDESTY,
        WEL_LPKGNS,
        WEL_LPKGNR,
        WEL_LDESOP,
        WEL_LPHYSI,
        WEL_LWORLD,
        WEL_LPERAC,
        WEL_LTRAVE,
        WEL_LQUEND,
        WEL_LEXBNP,
        WEL_LEXBNC,
        WEL_LPKCDE,
        WEL_LPKGFL,
        WEL_HMKT_SEG,
        WEL_LHSPOI,
        WEL_LHSPDS,
        WEL_LHSPEO,
        WEL_LHSPEB,
        WEL_LHSPXO,
        WEL_LHSPVB,
        WEL_LHSPLO,
        WEL_AMKT_SEG,
        WEL_LANCOI,
        WEL_LANCDS,
        WEL_LANCEO,
        WEL_LANCEB,
        WEL_LANCXO,
        WEL_LANCVB,
        WEL_LANCLO,
        WEL_LMEDCC,
        WEL_LMEDOI,
        WEL_LMEDDS,
        WEL_LMEDEO,
        WEL_LMEDEB,
        WEL_LMEDXO,
        WEL_LMEDVB,
        WEL_LMEDLO,
        WEL_LNPHCC,
        WEL_LNPHOI,
        WEL_LNPHDS,
        WEL_LNPHEO,
        WEL_LNPHEB,
        WEL_LNPHXO,
        WEL_LNPHVB,
        WEL_LNPHLO,
        WEL_LSRSEC,
        WEL_LSRSED,
        WEL_LEXNPD,
        WEL_LPHIRF,
        WEL_LLHCFL,
        WEL_LBASER,
        WEL_LBAS30,
        WEL_LBASAL,
        WEL_LBAS3A,
        WEL_LREBAM,
        WEL_LALLFL,
        WEL_LALPER,
        WEL_LALLAM,
        WEL_LLHCNA,
        WEL_LLHCWA,
        WEL_LL30NA,
        WEL_LL30WA,
        WEL_LLOADP,
        WEL_LLOADA,
        WEL_LLOAD1,
        WEL_LLOAD2,
        WEL_CEAGE1,
        WEL_CEAGE2,
        WEL_NODYS1,
        WEL_NODYS2,
        WEL_LNRATE,
        WEL_REBATE_PERCENTAGE,
        WEL_REBATE_REASON_CODE,
        WEL_REBATE_TIER_CODE,
        WEL_LPDSNO,
        WEL_LPDSTY,
        WEL_LPDSNM,
        WEL_LPYRCD,
        WEL_LALLGP,
        WEL_LALLTY,
        WEL_LALLPC,
        WEL_LRGATY,
        WEL_LRGPAC,
        WEL_LRGBSB,
        WEL_LRGINO,
        WEL_LRGINM,
        WEL_LRGBNM,
        WEL_LRGBRN,
        WEL_LRGPDT,
        WEL_LRGPYF,
        WEL_LRGPYA,
        WEL_LSGATY,
        WEL_LSGPAC,
        WEL_LSGBSB,
        WEL_LSGINO,
        WEL_LSGINM,
        WEL_LSGBNM,
        WEL_LSGBRN,
        WEL_LSGPDT,
        WEL_LSGPYF,
        WEL_LSGPYA,
        WEL_LSTPYF,
        WEL_LSTPYA,
        CORP_TABLE,
        CORP_CODE,
        CORP_LINE


    }
}
