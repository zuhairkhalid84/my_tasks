﻿using System;
using NUnit.Framework;
using System.IO;
using System.Reflection;
using Moq;
using ABnote.ProFound;
using ABnote.ProFound.Utilities.OrderData;

namespace ProFound.Custom.BUPA.Stage1.WELCOME.Tests
{
    [TestFixture]
    public class ParserTests
    {
        private const string GoodConfig = @"<Profile>
				    <IndexFields>
					<Field Name=""WEL_LNDSTO"" Start=""0"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNAADD"" Start=""2"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSPSIO"" Start=""3"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_SERV_CTRE"" Start=""7"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBRANO"" Start=""8"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LCOVNO"" Start=""10"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LTHEME"" Start=""18"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_REC_TYPE"" Start=""28"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_POSTCODE"" Start=""43"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_RUN_DATE"" Start=""47"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_SEQ_NO"" Start=""55"" Length=""6""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_REC_SEQ_NO"" Start=""61"" Length=""6""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_PRVIND"" Start=""67"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LGSRTO"" Start=""68"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_DSEGNO"" Start=""78"" Length=""6""><TrimMode>Both</TrimMode></Field>
				   </IndexFields>
				   <AddressFields>
					<Field Name=""WEL_ALADTLE"" Start=""84"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADGVN"" Start=""94"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADINI"" Start=""109"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADSNM"" Start=""110"" Length=""30""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALMEMN3"" Start=""140"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALSALU2"" Start=""200"" Length=""42""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADDMN_1"" Start=""242"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADDMN_2"" Start=""282"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADDMN_3"" Start=""322"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ALADDMN_4"" Start=""362"" Length=""40""><TrimMode>Both</TrimMode></Field>
				   </AddressFields>
				   <MembershipFields>
					<Field Name=""WEL_LENRTY"" Start=""84"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPCGDT"" Start=""87"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LENRDT"" Start=""95"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEXTDT"" Start=""103"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LREAS2"" Start=""111"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LFUNN2"" Start=""126"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBADN2"" Start=""128"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLAPRD"" Start=""130"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBUSTY"" Start=""134"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBUSI4"" Start=""135"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LTMRED"" Start=""136"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LCSRVC"" Start=""140"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LAMXID"" Start=""141"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LJOIDT"" Start=""142"" Length=""17""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEMTY"" Start=""159"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LFMYTY"" Start=""174"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LFMYDS"" Start=""176"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPHSTY"" Start=""191"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPHSCV"" Start=""206"" Length=""27""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDENOS"" Start=""233"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPARAID"" Start=""235"" Length=""16""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPSRTY"" Start=""251"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPSRID"" Start=""252"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEPEID"" Start=""267"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LFLSID"" Start=""268"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLHCT1"" Start=""278"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBRANA"" Start=""288"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBRAND"" Start=""298"" Length=""100""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBADGA"" Start=""398"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBADGD"" Start=""402"" Length=""100""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LORGXT"" Start=""502"" Length=""10""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEMAIL"" Start=""512"" Length=""80""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_OSHCAOF"" Start=""592"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXID"" Start=""596"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXGN"" Start=""611"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXGA1"" Start=""671"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXGA2"" Start=""711"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXGA3"" Start=""751"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_ORGXGA4"" Start=""791"" Length=""40""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_STUDNUM"" Start=""831"" Length=""20""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_VISA_NUMBER"" Start=""859"" Length=""20""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_DATEPT"" Start=""851"" Length=""8""><TrimMode>Both</TrimMode></Field>
				   </MembershipFields>
				   <PersonFields>
					<Field Name=""WEL_LDEGVN"" Start=""84"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDEINI"" Start=""99"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDESNM"" Start=""100"" Length=""30""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDERLN"" Start=""130"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDESFX"" Start=""138"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDEDOB"" Start=""140"" Length=""17""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDESTY"" Start=""157"" Length=""1""><TrimMode>Both</TrimMode></Field>

				   </PersonFields>
				   <ProductFields>
					<Field Name=""WEL_LPKGNS"" Start=""84"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPKGNR"" Start=""85"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LDESOP"" Start=""86"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPHYSI"" Start=""87"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LWORLD"" Start=""88"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPERAC"" Start=""89"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LTRAVE"" Start=""90"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LQUEND"" Start=""91"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEXBNP"" Start=""95"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEXBNC"" Start=""96"" Length=""7""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPKCDE"" Start=""103"" Length=""4""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPKGFL"" Start=""107"" Length=""100""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_HMKT_SEG"" Start=""207"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPOI"" Start=""209"" Length=""7""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPDS"" Start=""216"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPEO"" Start=""276"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPEB"" Start=""278"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPXO"" Start=""280"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPVB"" Start=""282"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LHSPLO"" Start=""283"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_AMKT_SEG"" Start=""284"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCOI"" Start=""286"" Length=""7""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCDS"" Start=""293"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCEO"" Start=""353"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCEB"" Start=""355"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCXO"" Start=""357"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCVB"" Start=""359"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LANCLO"" Start=""360"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDCC"" Start=""361"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDOI"" Start=""363"" Length=""7""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDDS"" Start=""370"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDEO"" Start=""430"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDEB"" Start=""432"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDXO"" Start=""434"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDVB"" Start=""436"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LMEDLO"" Start=""437"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHCC"" Start=""438"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHOI"" Start=""440"" Length=""7""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHDS"" Start=""447"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHEO"" Start=""507"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHEB"" Start=""509"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHXO"" Start=""511"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHVB"" Start=""513"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNPHLO"" Start=""514"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSRSEC"" Start=""515"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSRSED"" Start=""523"" Length=""240""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LEXNPD"" Start=""763"" Length=""1""><TrimMode>Both</TrimMode></Field>
				   </ProductFields>
				   <LHCFields>
					<Field Name=""WEL_LPHIRF"" Start=""84"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLHCFL"" Start=""85"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBASER"" Start=""86"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBAS30"" Start=""94"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBASAL"" Start=""102"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LBAS3A"" Start=""110"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LREBAM"" Start=""118"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALLFL"" Start=""126"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALPER"" Start=""127"" Length=""5""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALLAM"" Start=""132"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLHCNA"" Start=""140"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLHCWA"" Start=""148"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LL30NA"" Start=""156"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LL30WA"" Start=""164"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLOADP"" Start=""172"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLOADA"" Start=""174"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLOAD1"" Start=""182"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LLOAD2"" Start=""184"" Length=""2""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_CEAGE1"" Start=""186"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_CEAGE2"" Start=""189"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_NODYS1"" Start=""192"" Length=""5""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_NODYS2"" Start=""197"" Length=""5""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LNRATE"" Start=""202"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_REBATE_PERCENTAGE"" Start=""210"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_REBATE_REASON_CODE"" Start=""213"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_REBATE_TIER_CODE"" Start=""214"" Length=""4""><TrimMode>Both</TrimMode></Field>
				   </LHCFields>
				   <PaymentFields>
					<Field Name=""WEL_LPDSNO"" Start=""84"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPDSTY"" Start=""99"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPDSNM"" Start=""102"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LPYRCD"" Start=""162"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALLGP"" Start=""163"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALLTY"" Start=""178"" Length=""1""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LALLPC"" Start=""179"" Length=""5""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGATY"" Start=""184"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGPAC"" Start=""187"" Length=""20""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGBSB"" Start=""207"" Length=""6""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGINO"" Start=""213"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGINM"" Start=""216"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGBNM"" Start=""276"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGBRN"" Start=""336"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGPDT"" Start=""396"" Length=""17""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGPYF"" Start=""413"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LRGPYA"" Start=""428"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGATY"" Start=""436"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGPAC"" Start=""439"" Length=""20""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGBSB"" Start=""459"" Length=""6""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGINO"" Start=""465"" Length=""3""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGINM"" Start=""468"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGBNM"" Start=""528"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGBRN"" Start=""588"" Length=""60""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGPDT"" Start=""648"" Length=""17""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGPYF"" Start=""665"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSGPYA"" Start=""680"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSTPYF"" Start=""688"" Length=""15""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_LSTPYA"" Start=""703"" Length=""8""><TrimMode>Both</TrimMode></Field>
				   </PaymentFields>
				   <CorporateFields>
					<Field Name=""WEL_CORP_TABLE"" Start=""84"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_CORP_CODE"" Start=""92"" Length=""8""><TrimMode>Both</TrimMode></Field>
					<Field Name=""WEL_CORP_LINE"" Start=""100"" Length=""80""><TrimMode>Both</TrimMode></Field>

				   </CorporateFields>

				</Profile>";
        [Test]
        public void TestMethod1()
        {
            var mockResourceManager = new Mock<IResourceManager>();
            var parser = new FileParser();
            var stream = RequestEmbeddedResource("TestFile.txt");
            OrderDataMemoryStream orderData = new OrderDataMemoryStream(ConvertStreamToByteArray(stream), "TestFile.txt");
            parser.Configure(GoodConfig);
            var dataSet = parser.Process(orderData);            

        }

        public Stream RequestEmbeddedResource(string resourceName)
        {
            resourceName = string.Format("{0}.{1}", GetType().Namespace, resourceName);
            return Assembly.GetAssembly(GetType()).GetManifestResourceStream(resourceName);
        }

        public byte[] ConvertStreamToByteArray(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }
    }
}
