﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Collections.ObjectModel;
using ABnote.ProFound.Utilities.DIService;
using ABnote.ProFound.PMS.Interfaces;

namespace ABnote.ProFound.PMS
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class SubProductionSplit : Page
    {
        private DAL _database;
        

        string[] steps = new string[] { "Datacard", "cardink", "DataCardV2" };
        public SubProductionSplit()
        {
            InitializeComponent();
            _database = new DAL("Server=172.31.33.130;Database=ProFound;User Id=user_WfWorker;Password=4fsdFwo#32S;MultipleActiveResultSets=True;");
        }


           

        private void ShowJobList()
        {
            
            //ProductionDataSource = new ObservableCollection<DataModel.Production>(productions);
            //radTreeView1.ItemsSource = productions;
            
            //SplitGrid.Columns[0].Visible = false;
            //SplitGrid.Columns[3].Width = 150;
            //SplitGrid.Columns[6].Width = 50;
            //SplitGrid.Columns[7].Width = 75;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowJobList();
        }

        private void btnSplit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void radTreeView1_Checked(object sender, Telerik.Windows.RadRoutedEventArgs e)
        {
            //(e.Source as Telerik.Windows.Controls.RadTreeViewItem).Foreground = new SolidColorBrush(Colors.Green);
            
        }
    }


    public class ProductionData1
    {
        public List<Interfaces.IProductionJob> ProductionDataSource
        {
            get;
            set;
        }
        public ProductionData1()
        {
            try
            {

                IRegistrationService registrationService = (IRegistrationService)ServiceLocator.GetService(typeof(IRegistrationService));
               

                var service = (IPMSShiftLeader)ServiceLocator.GetService(typeof(IPMSShiftLeader));

                ProductionDataSource = service.GetReadyProductionJobs(2).ToList();
            }
            catch (Exception ex)
            { 
            
            }
        }
    }
}
