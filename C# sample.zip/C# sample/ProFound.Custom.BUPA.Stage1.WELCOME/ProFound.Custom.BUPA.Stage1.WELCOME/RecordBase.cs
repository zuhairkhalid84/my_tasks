﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public class RecordBase
    {
        public void PopulateFields(string line, DataRow row, string columnSuffix, List<Field> mapList)
        {   
            if (line.Length != 879)
            {
                throw new Exception("Welcome File record length is not correct");
            }         
            foreach (var field in mapList)
            {
                row[field.Name + columnSuffix] = line.Substring(field.Start, field.Length).Trim();
            }
           
        }
    }
}
