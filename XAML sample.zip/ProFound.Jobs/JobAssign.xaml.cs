﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace ABnote.ProFound.PMS
{
    /// <summary>
    /// Interaction logic for JobAssign.xaml
    /// </summary>
    public partial class JobAssign : Page
    {
        private DAL _database;

        //string[] steps = new string[] { "Datacard", "cardink" };
        private DataTable _dtUnAssign;
        private DataTable _dtAssign;

        ObservableCollection<ProductionI> _obUnAssignList;
        ObservableCollection<ProductionI> _obAssignList;

        string[] steps = new string[] { "Datacard", "DataCardV2" };
        public JobAssign()
        {
            InitializeComponent();
            _database = new DAL("Server=172.31.33.130;Database=ProFound;User Id=user_WfWorker;Password=4fsdFwo#32S;MultipleActiveResultSets=True;");
            
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            BindMachineList();
            BindCustomerList();
            PopulateUnAssignTree(0);
            //PopulatAssignedTree();
        }

        private void PopulateUnAssignTree(int customerId)
        {
            _dtUnAssign = _database.GetUnAssignJobListByCustomer(steps, customerId);
            //var dtNotAssign = _dtUnAssign.AsEnumerable().Where(fld => fld.Field<int>("Machine_ID") == null);
            _obUnAssignList = GetProductionData(_dtUnAssign);
            FillTree(_obUnAssignList, trvUnAssing);
        }

        private void PopulatAssignedTree(int machineId)
        {
            _dtAssign = _database.GetUnAssignJobListByMahine(steps, machineId);
            if (_dtAssign.AsEnumerable().Where(fld => fld.Field<int?>("Machine_ID") != null).Count() > 0)
            {
                //var dtAssigned = _dtAssign.AsEnumerable().Where(fld => fld.Field<int>("Machine_ID") != null);
                _obAssignList = GetProductionData(_dtAssign);
                FillTree(_obAssignList, trvAssigned);
            }
        }

        //private ObservableCollection<ProductionI> GetProductionData(IEnumerable<ProductionData> productionData)
        //{
        //    try
        //    {
        //       return ProductionHierarchi.GetProduction(productionData);

        //    }catch(Exception exception)
        //    {
        //        throw exception;
        //    }
        //}
        private ObservableCollection<ProductionI> GetProductionData(DataTable dtproductionData)
        {
            try
            {
                return ProductionHierarchi.GetProduction(dtproductionData);
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        private void FillTree(ObservableCollection<ProductionI> productions, TreeView treeView)
        {

            DataTemplate template = GetHeaderTemplate();
            treeView.Items.Clear();
            foreach (ProductionI production in productions)
            {
                
                TreeViewItem item = new TreeViewItem();            
                item.HeaderTemplate = template;
                item.Header = production.ProductionDescription;
                //item.Selected += NodeSelected;
                item.Unselected += item_Unselected;
                item.Tag = production.ProductionId;
                

                foreach (Productionunit pu in production.Productionunits)
                {
                    TreeViewItem child = new TreeViewItem();
                    child.HeaderTemplate = template;
                    child.Header = pu.PUDescription;
                   // child.Selected += NodeSelected;
                    child.Unselected += item_Unselected;
                    child.Tag = pu.SubProductionId;
                    

                    item.Items.Add(child);
                }

                item.IsExpanded = true;
                treeView.Items.Add(item);
            }
            

        }

        void item_Unselected(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("item_UnSelected");
        }

        void item_Selected(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("item_Selected");
        }
        private DataTemplate GetHeaderTemplate()
        {
            //create the data template
            //DataTemplate dataTemplate = new DataTemplate();
            HierarchicalDataTemplate dataTemplate = new HierarchicalDataTemplate();

            //create stack pane;
            FrameworkElementFactory stackPanel = new FrameworkElementFactory(typeof(StackPanel));
            stackPanel.Name = "parentStackpanel";
            stackPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

            // Create check box
            FrameworkElementFactory checkBox = new FrameworkElementFactory(typeof(CheckBox));
            checkBox.Name = "Chk";
            checkBox.SetValue(CheckBox.NameProperty, "Chk");
            checkBox.SetValue(CheckBox.IsCheckedProperty, new Binding() { Path = new PropertyPath("IsChecked"), });
            checkBox.SetValue(CheckBox.TagProperty, new Binding() );
           // checkBox.SetValue(CheckBox.TagProperty, new Binding());
            checkBox.SetValue(CheckBox.MarginProperty, new Thickness(2));
            //checkBox.SetValue(CheckBox.IsCheckedProperty, new Binding());
            //checkBox.SetValue(CheckBox.TagProperty, new Binding() { Path = new PropertyPath("ProductionDescription") });
            //checkBox.SetValue(CheckBox.TextProperty, new Binding() { Path = new PropertyPath("ProductionDescription") });
            checkBox.AddHandler(CheckBox.CheckedEvent, new RoutedEventHandler(CheckBox_Checked));
            checkBox.AddHandler(CheckBox.UncheckedEvent, new RoutedEventHandler(CheckBox_UnChecked));
            //checkBox.
            //checkBox.AddHandler(CheckBox., new RoutedEventHandler(CheckBox_Checked));
            stackPanel.AppendChild(checkBox);

            // Create Image 
            //FrameworkElementFactory image = new FrameworkElementFactory(typeof(Image));
            //image.SetValue(Image.MarginProperty, new Thickness(2));
            //image.SetBinding(Image.SourceProperty, new Binding() { Path = new PropertyPath("ImageUrl") });
            //stackPanel.AppendChild(image);

            // create text
            FrameworkElementFactory label = new FrameworkElementFactory(typeof(TextBlock));
            label.SetBinding(TextBlock.TextProperty, new Binding() );
            label.SetValue(TextBlock.ToolTipProperty, new Binding() { Path = new PropertyPath("PUDescription") });

            stackPanel.AppendChild(label);


            //set the visual tree of the data template
            dataTemplate.VisualTree = stackPanel;

            return dataTemplate;

        }
        

        void checkBox_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        void checkBox_Checked(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void BindMachineList()
        {
            try
            {
                cmbMachine.ItemsSource = _database.GetMachineList();
                
            }catch(Exception exception)
            {
                throw exception;
            }
        }

        private void BindCustomerList()
        {
            try
            {
                var query = (from LS in _database.DB.LoadingSessions
                         join CUS in _database.DB.ERPCustomers
                      on LS.Customer_ID equals CUS.Customer_ID
                         select new Customer
                         {
                             Customer_ID= CUS.Customer_ID.ToString(),
                             Name = CUS.Name,
                         }).Distinct();

                cmbCustomer.Items.Clear();
                cmbCustomer.ItemsSource = query;
                
                //cmbCustomer.ItemsSource  = _database.GetCustomerList();// ERPCustomers

            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        private void cmbMachine_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //MessageBox.Show(cmbMachine.SelectedValue.ToString());
            int machineId;
            if (int.TryParse(cmbMachine.SelectedValue.ToString(), out machineId))
            {
                PopulatAssignedTree(machineId);
            }
        }

        private void cmbCustomer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //MessageBox.Show(cmbCustomer.SelectedValue.ToString());
            int customerId;
            if ((cmbCustomer.SelectedValue != null) && (int.TryParse(cmbCustomer.SelectedValue.ToString(), out customerId)))
            {
                trvUnAssing.Items.Clear();
                PopulateUnAssignTree(customerId);
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            var chk = (CheckBox)sender;
            bool? isChecked = chk.IsChecked;
            TreeViewItem parentItem = GetTreeViewItemClicked((FrameworkElement)e.OriginalSource);
            if(parentItem.Items.Count > 0)
            {
                foreach (TreeViewItem item in parentItem.Items)
                {
                    UIElement ele = GetChildControl(item, "Chk");
                    ele.SetValue(CheckBox.IsCheckedProperty, isChecked);
                }
            }

        }

        private void CheckBox_UnChecked(object sender, RoutedEventArgs e)
        {
            var chk = (CheckBox)sender;
            bool? isChecked = chk.IsChecked;
            TreeViewItem currentItem = GetTreeViewItemClicked((FrameworkElement)e.OriginalSource);
            if (currentItem.HasItems)
            //if (currentItem.HasItems)
            {
                foreach (TreeViewItem item in currentItem.Items)
                {
                    UIElement ele = GetChildControl(item, "Chk");
                    
                    if (Boolean.Parse(ele.GetValue(CheckBox.IsCheckedProperty).ToString()) == true)
                        ele.SetValue(CheckBox.IsCheckedProperty, false);
                }
            }
            //else
            //{
            //    if (currentItem.IsSelected)
            //    {
            //        TreeViewItem parent = GetTreeViewItemClicked(currentItem.Parent);
            //        UIElement ele = GetChildControl(parent, "Chk");
            //        ele.SetValue(CheckBox.IsCheckedProperty, false);
            //    }
            //}

            
            //if (parentItem > 0)
            //{
            //    foreach (TreeViewItem item in parentItem.Items)
            //    {
            //        UIElement ele = GetChildControl(item, "Chk");
            //        ele.SetValue(CheckBox.IsCheckedProperty, isChecked);
            //    }
            //}
        }

        private TreeViewItem GetTreeViewItemClicked(DependencyObject sender)
        {
            while (sender != null && !(sender is TreeViewItem))
                sender = VisualTreeHelper.GetParent(sender);
            return sender as TreeViewItem;
        }


        //private void NodeSelected(object sender,
        //                     RoutedEventArgs e)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    TreeViewItem currContainer = e.OriginalSource as TreeViewItem;
        //    ProductionI item;
        //    while (currContainer != null)
        //    {
        //        item = currContainer.DataContext as ProductionI;
        //        sb.Insert(0, "/" + item.ProductionDescription);
        //        currContainer = getParent(currContainer);
        //    }
        //    MessageBox.Show("Path: " + sb.ToString());

        //}

        TreeViewItem getParent(TreeViewItem container)
        {
            DependencyObject parent = VisualTreeHelper.GetParent(container);
            while (parent != null && !(parent is TreeViewItem))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            return parent as TreeViewItem;


        }

        private UIElement GetChildControl(DependencyObject parentObject, string childName)
        {

            UIElement element = null;

            if (parentObject != null)
            {
                int totalChild = VisualTreeHelper.GetChildrenCount(parentObject);
                for (int i = 0; i < totalChild; i++)
                {
                    DependencyObject childObject = VisualTreeHelper.GetChild(parentObject, i);

                    if (childObject is FrameworkElement && ((FrameworkElement)childObject).Name == childName)
                    {
                        element = childObject as UIElement;
                        break;
                    }

                    // get its child
                    element = GetChildControl(childObject, childName);
                    if (element != null) break;
                }
            }

            return element;
        }


        private UIElement UpdateChildControl(DependencyObject parentObject, bool isChecked)
        {

            UIElement element = null;

            if (parentObject != null)
            {
                var item = VisualTreeHelper.GetParent(parentObject);
                int totalChild = VisualTreeHelper.GetChildrenCount(parentObject);
                for (int i = 0; i < totalChild; i++)
                {
                    DependencyObject childObject = VisualTreeHelper.GetChild(parentObject, i);

                    if (childObject is CheckBox)
                    {
                        //element = childObject as UIElement;
                        childObject.SetValue(CheckBox.IsCheckedProperty, isChecked);
                        element = childObject as UIElement;
                        break;
                    }

                    // get its child
                    element = UpdateChildControl(childObject, isChecked);
                    if (element != null) break;
                }
            }

            return element;
        }

        private void btnAssign_Click(object sender, RoutedEventArgs e)
        {
            if (cmbMachine.SelectedIndex <0)
            {
                MessageBox.Show("Please Select Machine", "Profound Information");
                return;
            }
            
            List<Productionunit> pus;
            foreach (TreeViewItem item in trvUnAssing.Items)
            {
                if(item.HasItems)
                {
                    pus = new List<Productionunit>();
                    foreach(TreeViewItem child in item.Items)
                    {
                        UIElement ele = GetChildControl(item, "Chk");
                        if (Boolean.Parse(ele.GetValue(CheckBox.IsCheckedProperty).ToString()) == true) 
                        { 
                            //MessageBox.Show(child.Tag.ToString());
                            //Update SubProduction with Machine Id.
                            //////var row = _database.DB.SubProductions.Where(r => r.SubProduction_ID == int.Parse(child.Tag.ToString())).Single();
                            //////row.Machine_ID = int.Parse(cmbMachine.SelectedValue.ToString());
                            //////row.Status = 30;
                            var row = _dtUnAssign.AsEnumerable().Where(r => r.Field<int>("SubProduction_ID") == int.Parse(child.Tag.ToString())).First();
                            row["Machine_ID"] = int.Parse(cmbMachine.SelectedValue.ToString());
                            row["Status"] = "Assigned";
                            _dtAssign.ImportRow(row);
                            _dtUnAssign.Rows.Remove(row);
                        }
                    }

                }
                
            }
            //PopulatAssignedTree(int.Parse(cmbMachine.SelectedValue.ToString()));
            _obAssignList = GetProductionData(_dtAssign);
            FillTree(_obAssignList, trvAssigned);

            _obUnAssignList = GetProductionData(_dtUnAssign);
            FillTree(_obUnAssignList, trvUnAssing);

            //if (cmbCustomer.SelectedIndex != -1)
            //    PopulateUnAssignTree(int.Parse(cmbCustomer.SelectedValue.ToString()));
        }

        private bool UpdateMachineId(int subProductionId, int machineId)
        {
            try
            {
                SubProduction subproduction = _database.DB.SubProductions.Single(c=>c.SubProduction_ID == subProductionId);
                subproduction.Machine_ID = machineId;

                return true;
            }catch(Exception exception)
            {
                throw exception;
            }

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //if(MessageBox.Show())

                foreach (DataRow row in _dtAssign.Rows)
                {
                    var dbRow = _database.DB.SubProductions.Where(sp => sp.SubProduction_ID == row.Field<int>("SubProduction_ID")).Single();
                    if (dbRow != null)
                    {
                        if (row["Machine_Id"] != DBNull.Value)
                            dbRow.Machine_ID = int.Parse(row["Machine_ID"].ToString());

                        dbRow.Status = 30;
                    }
                }
                //Update UnAssign 
                foreach (DataRow row in _dtUnAssign.Rows)
                {
                    var dbRow = _database.DB.SubProductions.Where(sp => sp.SubProduction_ID == row.Field<int>("SubProduction_ID")).Single();
                    if (dbRow != null)
                    {
                        if (string.IsNullOrEmpty(row["Machine_Id"].ToString()) || (row["Machine_Id"] != DBNull.Value))
                            dbRow.Machine_ID = null;

                        dbRow.Status = 10;
                    }
                }

                _database.DB.SubmitChanges();
            }catch(Exception exception)
            {
                throw exception;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUnAssign_Click(object sender, RoutedEventArgs e)
        {
            if (cmbMachine.SelectedIndex < 0)
            {
                MessageBox.Show("Please Select Machine", "Profound Information");
                return;
            }
            
            foreach (TreeViewItem item in trvAssigned.Items)
            {
                if (item.HasItems)
                {
                    foreach (TreeViewItem child in item.Items)
                    {
                        UIElement ele = GetChildControl(item, "Chk");
                        if (Boolean.Parse(ele.GetValue(CheckBox.IsCheckedProperty).ToString()) == true)
                        {
                            //MessageBox.Show(child.Tag.ToString());
                            var row = _dtAssign.AsEnumerable().Where(r => r.Field<int>("SubProduction_ID") == int.Parse(child.Tag.ToString())).First();
                            row["Machine_ID"] = DBNull.Value;
                            row["Status"] = "NEW";
                            _dtUnAssign.ImportRow(row);
                            _dtAssign.Rows.Remove(row);
                        }
                    }

                }

            }
            //PopulatAssignedTree(int.Parse(cmbMachine.SelectedValue.ToString()));
            _obAssignList = GetProductionData(_dtAssign);
            FillTree(_obAssignList, trvAssigned);

            _obUnAssignList = GetProductionData(_dtUnAssign);
            FillTree(_obUnAssignList, trvUnAssing);

        }
    }
}
