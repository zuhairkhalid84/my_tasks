﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using Telerik.Windows.Controls;

namespace ABnote.ProFound.PMS
{
    /// <summary>
    /// Interaction logic for JobViewNew.xaml
    /// </summary>
    public partial class JobViewNew : Page
    {
        private DAL _database;

        //string[] steps = new string[] { "Datacard", "cardink" };
        string[] steps = new string[] { "Datacard", "DataCardV2" };
        public JobViewNew()
        {
            InitializeComponent();
            _database = new DAL("Server=172.31.33.130;Database=ProFound;User Id=user_WfWorker;Password=4fsdFwo#32S;MultipleActiveResultSets=True;");
            //ShowJobList();
        }

        private void ShowJobList()
        {
            DataTable dt = _database.JobList(steps).Tables[0];
            ConfigGrid.ItemsSource = dt.DefaultView;
            //ConfigGrid.Columns[0].Visible = false;
            //ConfigGrid.Columns[3].Width = 150;
            //ConfigGrid.Columns[6].Width = 50;
            //ConfigGrid.Columns[7].Width = 75;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowJobList();
        }
    }
}
