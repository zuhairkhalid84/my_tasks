﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    class R10_PackEnd : RecordBase
    {
        public R10_PackEnd(StreamReader reader, DataRow row, string currentLine)
        {
            //if (currentLine.StartsWith(RecordTypes.PackEnd))
            //{
            //    foreach (DataRow cardRow in GlobalObjects.orderData.AsEnumerable().Where(c => c.Field<string>(OrderDataColumns.PACK_NO) == row[OrderDataColumns.PACK_NO].ToString()
            //                                                                                && c.Field<string>(OrderDataColumns.MEMBER_NO) == row[OrderDataColumns.MEMBER_NO].ToString()
            //                                                                                && c.Field<string>(OrderDataColumns.PACK_TYPE) == row[OrderDataColumns.PACK_TYPE].ToString()))
            //    {
            //        PopulateFields(currentLine, cardRow, string.Empty);
            //    }
            //}
            //else
            //{
            //    throw new Exception("Mandatory Record Type PACK_END missing for member number " + row.Field<string>(OrderDataColumns.MEMBER_NO));
            //}

        }
    }
}

