﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data;


namespace ABnote.ProFound.PMS
{
    public class ProductionHierarchi
    {
        static public ObservableCollection<ProductionI> ProductionList;
        static public ObservableCollection<ProductionI> GetProduction(IEnumerable<ProductionData> data)
        {
            try
            {
                ProductionList = new ObservableCollection<ProductionI>();
                var productionIds = data.AsEnumerable().Select(pd => pd.Production_ID).Distinct();
                foreach(var productionId in productionIds)
                {
                    IEnumerable<DataRow> dr = data.AsEnumerable().Where(pd => pd.Production_ID == productionId).Cast<DataRow>();
                    ProductionList.Add(new ProductionI(dr));
                }

                return ProductionList;
            }catch(Exception exception)
            {
                throw exception;
            }

        }
        static public ObservableCollection<ProductionI> GetProduction(DataTable data)
        {
            try
            {
                ProductionList = new ObservableCollection<ProductionI>();
                var productionIds = data.AsEnumerable().Select(pd => pd.Field<int>("Production_ID")).Distinct();
                foreach (var productionId in productionIds)
                {
                    var dr = data.AsEnumerable().Where(pd => pd.Field<int>("Production_ID") == productionId);
                    ProductionList.Add(new ProductionI(dr));
                }

                return ProductionList;
            }
            catch (Exception exception)
            {
                throw exception;
            }

        }
    }

    public class ProductionI : INotifyPropertyChanged
    {
        public int ProductionId;

        public string ProductionDescription;

        public ObservableCollection<Productionunit> Productionunits;

        bool isChecked;

        

        public bool IsChecked
        {
            get { return this.isChecked; }
            set
            {
                isChecked = value;
                RaisePropertyChanged("IsChecked");
            }
        }


        public ProductionI(IEnumerable<DataRow> rows)
        {
            Productionunits = new ObservableCollection<Productionunit>();
            var drFirst = rows.FirstOrDefault();
            ProductionId = drFirst.Field<int>("Production_ID");
            ProductionDescription = "[" + drFirst.Field<int>("Production_ID") + "]" + drFirst.Field<string>("Customer");
            
            foreach(var dr in rows)
                Productionunits.Add(new Productionunit(dr));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            if (propertyName == "IsChecked")
            {
                foreach (Productionunit child in Productionunits)
                    child.IsChecked = this.IsChecked;
            }
        }

    }

    public class Productionunit 
    {
        public int ProductionId;

        public string WorkOrder;

        public int PuNo;

        public string Machine_Id;

        public string Machine_Description;

        public string PUDescription;

        bool isChecked;

        public int SubProductionId;

        public bool _isAssigned ;

        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                //RaisePropertyChanged("IsChecked");
            }
        }

        public bool IsAssigned
        {
            get { return _isAssigned; }
            set
            {
                _isAssigned = value;
            }
        }
        

        public Productionunit(DataRow dr)
        {
            ProductionId = dr.Field<int>("Production_ID");
            WorkOrder = dr.Field<string>("WorkOrder");
            PuNo = dr.Field<int>("PU_No");
            if (dr["Machine_ID"] == DBNull.Value)
                Machine_Id = null;
            else
                Machine_Id = dr["Machine_ID"].ToString();

            PUDescription = "PU-" + PuNo 
                            + " [" + WorkOrder + "] " 
                            +  dr.Field<string>("PuDescription") 
                            + "-" + dr.Field<int>("NumberOfRecords");
            SubProductionId = dr.Field<int>("SubProduction_ID");
            IsAssigned = dr.Field<string>("Status") == "Assigned" ? true : false;
        }
    }

}
