﻿using System.Collections.Generic;
using System.Security.Cryptography;
using ABnote.Utility.Configuration;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Reflection;
using System;

namespace ProFound.Custom.BUPA.Stage1.WELCOME
{
    public class ConfigProfileHelper
    {
        private readonly ProfileHelper<AesManaged> _profileHelper;
        public List<Field> MapIndexFields { get; private set; }
        public List<Field> MapAddressFields { get; private set; }
        public List<Field> MapMembershipFields { get; private set; }
        public List<Field> MapPersonFields { get; private set; }
        public List<Field> MapProductFields { get; private set; }
        public List<Field> MapLHCFields { get; private set; }
        public List<Field> MapPaymentFields { get; private set; }
        public List<Field> MapCorporateFields { get; private set; }
        public List<Field> MapAllFields { get; private set; }


        public ConfigProfileHelper(string configuration)
        {
            _profileHelper = new ProfileHelper<AesManaged>();
            _profileHelper.Parse(configuration);
            Initialize();
        }

        /// <summary>
        /// Initializes the specified XML doc.
        /// </summary>
        /// <param name="xmlDoc">The XML doc.</param>
        public void Initialize()
        {
            MapIndexFields = new List<Field>();
            MapAddressFields = new List<Field>();
            MapMembershipFields = new List<Field>();
            MapPersonFields = new List<Field>();
            MapProductFields = new List<Field>();
            MapLHCFields = new List<Field>();
            MapPaymentFields = new List<Field>();
            MapCorporateFields = new List<Field>();
            MapAllFields = new List<Field>();

            PopulateListValues("IndexFields", MapIndexFields);
            PopulateListValues("AddressFields", MapAddressFields);
            PopulateListValues("MembershipFields", MapMembershipFields);
            PopulateDynamicListValues("PersonFields", MapPersonFields);
            PopulateListValues("ProductFields", MapProductFields);
            PopulateListValues("LHCFields", MapLHCFields);
            PopulateListValues("PaymentFields", MapPaymentFields);
            PopulateDynamicListValues("CorporateFields", MapCorporateFields);

        }

        private void PopulateListValues (string elementName, List<Field> mapList)
        {
            foreach (var element in _profileHelper.GetAllElements(elementName, "Field"))
            {
                string temp;

                var field = new Field();
                if (_profileHelper.GetAttributeValue(element, "Name", out temp))
                {
                    field.Name = temp;
                }
                if (_profileHelper.GetAttributeValue(element, "Length", out temp))
                {
                    field.Length = Convert.ToInt32(temp);
                }
                if (_profileHelper.GetAttributeValue(element, "Start", out temp))
                {
                    field.Start = Convert.ToInt32(temp);
                }
                mapList.Add(field);
                MapAllFields.Add(field);
            }
        }

        private void PopulateDynamicListValues(string elementName, List<Field> mapList)
        {
            foreach (var element in _profileHelper.GetAllElements(elementName, "Field"))
            {
                string temp;

                var field = new Field();
                if (_profileHelper.GetAttributeValue(element, "Name", out temp))
                {
                    field.Name = temp;
                }
                if (_profileHelper.GetAttributeValue(element, "Length", out temp))
                {
                    field.Length = Convert.ToInt32(temp);
                }
                if (_profileHelper.GetAttributeValue(element, "Start", out temp))
                {
                    field.Start = Convert.ToInt32(temp);
                }
                mapList.Add(field);
                
            }
        }


    }

    public struct Field
    {
        #region Public Properties

        public int Start { get; set; }

        public int Length { get; set; }

        public string Name { get; set; }

        #endregion
    }
}
